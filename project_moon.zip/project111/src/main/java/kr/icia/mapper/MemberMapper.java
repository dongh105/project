package kr.icia.mapper;

import kr.icia.domain.MemberVO;

public interface MemberMapper {
	public MemberVO read(String userid);
}
